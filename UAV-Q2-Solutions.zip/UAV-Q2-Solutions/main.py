file_input = open("Input.txt", "r")
input_array = file_input.readline().split()
file_output = open("Output.txt", "w")
H = float(input_array[0])
V = float(input_array[1])
L = float(input_array[2])
X = float(input_array[3])
Y = float(input_array[4])

# Check the given constraints
# 0 < 𝐻 < 180
if (not ((0 <= H) & (180 >= H))):
    file_output.write("Error H is not within range")
# 0 < V < 180
if (not ((0 <= V) & (180 >= V))):
    file_output.write("Error V is not within range")
if (not(0<L)):
  print ("Error V is not within range")
