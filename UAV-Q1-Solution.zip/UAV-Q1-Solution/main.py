file_input = open("Input.txt", "r")
input_array = file_input.readline().split()
file_output = open("Output.txt", "w")
N = float(input_array[0])
M = float(input_array[1])
Dx = float(input_array[2])
Dy = float(input_array[3])
K = int(input_array[4])

# Check the given constraints
# 3 ≤ 𝑁 ≤ 200000
if (not ((3 <= N) & (200000 >= N))):
    file_output.write("Error N is not within range")
# 3 ≤ 𝑀 ≤ 200000
if (not ((3 <= M) & (200000 >= M))):
    file_output.write("Error M is not within range")
# 0 < 𝐷𝑥 < 1
if (not ((0 <= Dx) & (1 >= Dx))):
    file_output.write("Error Dx is not within range")
# 0 < 𝐷y < 1
if (not ((0 <= Dy) & (1 >= Dy))):
    file_output.write("Error Dy is not within range")
# 1 < 𝐾 < 200000
if (not ((1 <= K) & (200000 >= Dy))):
    file_output.write("Error K is not within range")
# Calculating precision of Dx
decimalInDx = len(str(Dx).split(".")[1])
# Calculating precision of Dy
decimalInDy = len(str(Dy).split(".")[1])

for index in range(K):
        coordinates = file_input.readline().split()
        file_output.write(str(round(float(coordinates[0]) / Dx) * Dx) + " " + str(round(float(coordinates[1]) / Dy) * Dy)+ "\n")



