file_input = open("Input3.txt", "r")
input_array = file_input.readline().split()
file_output = open("Output3.txt", "w")
N = float(input_array[0])
M = float(input_array[1])
K = float(input_array[2])
P = float(input_array[3])
if (not((5<=N) and (N<=5000))):
  print ("Error N is not within range")
if (not((5<=M) and (M<=5000))):
  print ("Error M is not within range")
if (not((1<=P) and (P<=20))):
  print ("Error P is not within range")

